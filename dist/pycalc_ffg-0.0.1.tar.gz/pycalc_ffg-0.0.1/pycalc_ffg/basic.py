def somar(*args):
    final = 0
    for i in args:
        final += i
    return final


def subtrair(*args):
    final = 0
    for i in args:
        final -= i
    return final


def multiplicar(num1, num2):
    return num1*num2


def dividir(num1, num2):
    return num1/num2
