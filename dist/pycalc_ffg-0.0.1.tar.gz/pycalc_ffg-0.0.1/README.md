# pycalc_ffg

Description. 
The package pycalc_ffg is used to add some simple calculation features.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install pycalc

```bash
pip install pycalc_ffg
```

## Usage

```python
from pycalc_ffg import basic

basic.somar()
basic.subtrair()
basic.multiplicar()
basic.dividir()
```

```python
from pycalc_ffg import prime

prime.primos()
```

## Author
Felipe

## License
[MIT](https://choosealicense.com/licenses/mit/)